﻿using System.Diagnostics;
using System.Reflection;
using TestLib.attributes;
using TestLib.exceptions;
using TestLib.Threading;

namespace TestRunner;

public class TestRunner
{
    private static readonly object _consoleLock = new();

    private readonly int _maxThreads;
    private readonly int _minThreads;

    private readonly Dictionary<Type, object> _sharedContexts = new();
    private int _errors;
    private int _failed;
    private int _ignored;
    private int _passed;

    private CustomThreadPool? _pool;

    // Конструктор по умолчанию
    public TestRunner() : this(2, 4) { }
    
    public TestRunner(int minThreads, int maxThreads)
    {
        _minThreads = minThreads;
        _maxThreads = maxThreads;
    }

    public async Task RunAsync(Assembly assembly, bool parallel = true)
    {
        _passed = _failed = _ignored = _errors = 0;

        await InitializeRequiredContexts(assembly);

        var testCases = GetTestCases(assembly);

        SafePrint(() =>
            Console.WriteLine($"\nStarting {(parallel ? "CUSTOM POOL" : "SEQUENTIAL")} execution of {testCases.Count} tests..."));

        var sw = Stopwatch.StartNew();

        if (parallel)
        {
            _pool = new CustomThreadPool(_minThreads, _maxThreads, idleTimeoutMs: 5000);
            using var countdown = new CountdownEvent(testCases.Count);

            foreach (var tc in testCases)
            {
                await Task.Yield();

                _pool.Enqueue(() =>
                {
                    try
                    {
                        ExecuteTestCase(tc).GetAwaiter().GetResult();
                    }
                    finally
                    {
                        // Сигнал будет отправлен всегда, даже если тест "завис"
                        countdown.Signal();
                    }
                });
            }

            // Ждем завершения всех тестов в отдельной задаче, чтобы не блокировать UI
            await Task.Run(() => countdown.Wait());
            _pool.Dispose(); 
        }
        else
        {
            foreach (var tc in testCases) await ExecuteTestCase(tc);
        }

        sw.Stop();

        await CleanupSharedContexts();
        PrintSummary(sw.ElapsedMilliseconds);
    }

    private async Task InitializeRequiredContexts(Assembly assembly)
    {
        var contextTypes = assembly.GetTypes()
            .Where(t => t.GetCustomAttribute<TestClassAttribute>() != null)
            .Select(t => t.GetCustomAttribute<SharedContextAttribute>()?.ContextType)
            .Where(type => type != null)
            .Distinct();

        foreach (var ctxType in contextTypes) 
            await GetOrCreateSharedContextAsync(ctxType!);
    }

    private async Task<object> GetOrCreateSharedContextAsync(Type contextType)
    {
        lock (_sharedContexts)
        {
            if (_sharedContexts.TryGetValue(contextType, out var ctx)) return ctx;
        }

        var instance = Activator.CreateInstance(contextType)!;
        var init = contextType.GetMethods()
            .FirstOrDefault(m => m.GetCustomAttribute<SharedContextInitializeAttribute>() != null);
        
        if (init != null) await Invoke(instance, init);

        lock (_sharedContexts)
        {
            _sharedContexts[contextType] = instance;
        }
        return instance;
    }

    private List<TestCase> GetTestCases(Assembly assembly)
    {
        var list = new List<TestCase>();
        var classes = assembly.GetTypes().Where(t => t.GetCustomAttribute<TestClassAttribute>() != null);

        foreach (var @class in classes)
        {
            if (@class.GetCustomAttribute<IgnoreAttribute>() != null) continue;

            var methods = @class.GetMethods().Where(m => m.GetCustomAttribute<TestMethodAttribute>() != null);
            foreach (var method in methods)
            {
                var dataRows = method.GetCustomAttributes<DataRowAttribute>().ToList();
                if (dataRows.Any())
                    foreach (var row in dataRows)
                        list.Add(new TestCase(@class, method, row.Values, row.IgnoreMessage));
                else
                    list.Add(new TestCase(@class, method, null, null));
            }
        }
        return list;
    }

    private async Task ExecuteTestCase(TestCase tc)
    {
        var methodIgnore = tc.Method.GetCustomAttribute<IgnoreAttribute>();
        if (methodIgnore != null || tc.DataRowIgnoreMessage != null)
        {
            Interlocked.Increment(ref _ignored);
            SafePrint(() => PrintIgnore(FormatTestName(tc.Method, tc.Parameters),
                methodIgnore?.Message ?? tc.DataRowIgnoreMessage ?? "Ignored"));
            return;
        }

        try
        {
            ValidateMethodSignature(tc.Method);
            ValidateParameters(tc.Method, tc.Parameters);
        }
        catch (Exception ex)
        {
            Interlocked.Increment(ref _errors);
            SafePrint(() => PrintError(tc.Method.Name, ex.Message));
            return;
        }

        var timeoutAttr = tc.Method.GetCustomAttribute<TimeoutAttribute>();

        var timeoutMs = timeoutAttr?.Milliseconds ?? 3000; 

        using var cts = new CancellationTokenSource();
        var executionTask = RunSingle(tc);
        var timeoutTask = Task.Delay(timeoutMs, cts.Token);
        
        var finishedTask = await Task.WhenAny(executionTask, timeoutTask);

        if (finishedTask == timeoutTask)
        {
            Interlocked.Increment(ref _failed);
            SafePrint(() => PrintFail(FormatTestName(tc.Method, tc.Parameters), $"Timed out after {timeoutMs}ms (Thread abandoned)"));
            return; 
        }

        cts.Cancel(); // Тест успел, отменяем таймер
        await executionTask;
    }

    private async Task RunSingle(TestCase tc)
    {
        object? instance = null;
        try
        {
            instance = CreateInstance(tc.ClassType);
            var methods = tc.ClassType.GetMethods();
            var setup = methods.FirstOrDefault(m => m.GetCustomAttribute<SetUpAttribute>() != null);
            var teardown = methods.FirstOrDefault(m => m.GetCustomAttribute<TearDownAttribute>() != null);

            if (setup != null) await Invoke(instance, setup);
            
            // [ИЗМЕНЕНО] Вызываем Invoke через Task.Run, чтобы бесконечные циклы в тестах 
            // не блокировали поток, отвечающий за мониторинг таймаута.
            var testTask = Task.Run(() => tc.Method.Invoke(instance, tc.Parameters));
            var result = await testTask; 

            if (result is Task t) await t;

            if (teardown != null) await Invoke(instance, teardown);

            Interlocked.Increment(ref _passed);
            SafePrint(() => PrintSuccess(FormatTestName(tc.Method, tc.Parameters)));
        }
        catch (Exception ex)
        {
            var actualEx = ex is TargetInvocationException ? ex.InnerException : ex;

            if (actualEx is TestFailedException fe)
            {
                Interlocked.Increment(ref _failed);
                SafePrint(() => PrintFail(FormatTestName(tc.Method, tc.Parameters), fe.Message));
            }
            else if (actualEx is TestIgnoredException ie)
            {
                Interlocked.Increment(ref _ignored);
                SafePrint(() => PrintIgnore(FormatTestName(tc.Method, tc.Parameters), ie.Message));
            }
            else
            {
                Interlocked.Increment(ref _errors);
                SafePrint(() => PrintError(FormatTestName(tc.Method, tc.Parameters), actualEx?.Message ?? "Unknown Error"));
            }
        }
    }

    // ---------------- СЛУЖЕБНЫЕ МЕТОДЫ ----------------

    private object CreateInstance(Type type)
    {
        var sharedContextAttr = type.GetCustomAttribute<SharedContextAttribute>();
        if (sharedContextAttr != null)
        {
            if (_sharedContexts.TryGetValue(sharedContextAttr.ContextType, out var context))
            {
                var ctor = type.GetConstructor(new[] { sharedContextAttr.ContextType });
                if (ctor != null) return ctor.Invoke(new[] { context });
            }
        }
        return Activator.CreateInstance(type) ?? throw new Exception("Null instance");
    }

    private async Task CleanupSharedContexts()
    {
        foreach (var ctx in _sharedContexts.Values)
        {
            var cleanup = ctx.GetType().GetMethods()
                .FirstOrDefault(m => m.GetCustomAttribute<SharedContextCleanUpAttribute>() != null);
            if (cleanup != null) await Invoke(ctx, cleanup);
        }
    }

    private async Task Invoke(object instance, MethodInfo method)
    {
        var result = method.Invoke(instance, null);
        if (result is Task t) await t;
    }

    private void ValidateMethodSignature(MethodInfo method)
    {
        if (method.ReturnType != typeof(void) && method.ReturnType != typeof(Task))
            throw new InvalidTestSignatureException("Must return void or Task");
    }

    private void ValidateParameters(MethodInfo method, object[]? values)
    {
        var parameters = method.GetParameters();
        int valuesCount = values?.Length ?? 0;

        if (parameters.Length != valuesCount)
        {
            throw new Exception($"Parameter count mismatch. Expected {parameters.Length}, got {valuesCount}");
        }
    }
    
    private string FormatTestName(MethodInfo method, object[]? parameters)
    {
        return parameters == null ? method.Name : $"{method.Name}({string.Join(", ", parameters)})";
    }

    private void SafePrint(Action action)
    {
        lock (_consoleLock) { action(); }
    }

    private void PrintSuccess(string name)
    {
        Console.ForegroundColor = ConsoleColor.Green;
        Console.WriteLine($"PASS: {name}");
        Console.ResetColor();
    }

    private void PrintFail(string name, string msg)
    {
        Console.ForegroundColor = ConsoleColor.Red;
        Console.WriteLine($"FAIL: {name} -> {msg}");
        Console.ResetColor();
    }

    private void PrintIgnore(string name, string msg)
    {
        Console.ForegroundColor = ConsoleColor.Yellow;
        Console.WriteLine($"SKIP: {name} -> {msg}");
        Console.ResetColor();
    }

    private void PrintError(string name, string msg)
    {
        Console.ForegroundColor = ConsoleColor.DarkRed;
        Console.WriteLine($"ERROR: {name} -> {msg}");
        Console.ResetColor();
    }

    private void PrintSummary(long ms)
    {
        SafePrint(() =>
        {
            Console.WriteLine($"\nSUMMARY (Time: {ms}ms)");
            Console.WriteLine($"Passed: {_passed} | Failed: {_failed} | Ignored: {_ignored} | Errors: {_errors}");
        });
    }

    private record TestCase(Type ClassType, MethodInfo Method, object[]? Parameters, string? DataRowIgnoreMessage);
}